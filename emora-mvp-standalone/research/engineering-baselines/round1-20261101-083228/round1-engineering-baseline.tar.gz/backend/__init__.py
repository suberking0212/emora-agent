"""Standalone Emora backend."""
