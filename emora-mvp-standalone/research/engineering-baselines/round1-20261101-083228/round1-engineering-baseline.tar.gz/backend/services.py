import asyncio
import logging
import time
import json
from contextlib import asynccontextmanager
from contextvars import ContextVar
from uuid import uuid4
from collections.abc import Callable

from pydantic import ValidationError

from backend.agent import EmoraAgent, EmoraAgentGraph
from backend.contracts import (
    AgentAction,
    AgentDecision,
    AnalysisResponse,
    AnalysisStatus,
    DEFAULT_REASONING_EFFORT,
    QwenSafetyCategory,
    QwenSafetyLevel,
    ReasoningEffort,
)
from backend.provider import (
    JSONPath,
    PUBLIC_ANALYSIS_PROMPT,
    ProviderError,
    PublicAnalysisBrief,
    provider_metrics_var,
)
from backend.safety import GuardProtocolError, GuardUnavailableError
from backend.logging_config import request_id_var, session_id_var
from backend.storage import SessionConflict
from sqlalchemy.exc import IntegrityError

logger = logging.getLogger(__name__)
validation_var: ContextVar[dict | None] = ContextVar("validation", default=None)


def _validation(stage, status):
    if (state := validation_var.get()) is not None:
        state[stage] = status


class BusinessError(Exception):
    def __init__(self, status_code: int, code: str):
        self.status_code = status_code
        self.code = code


def validate_input_length(value: str, max_length: int) -> None:
    if len(value) > max_length:
        raise BusinessError(422, "input_too_long")


def _response(record: dict) -> AnalysisResponse:
    return AnalysisResponse(
        id=record["id"], original_input=record["original_input"],
        session_id=record.get("session_id"), turn_index=record.get("turn_index", 0),
        clarification_answer=record.get("clarification_answer"),
        deep_thinking=record.get("deep_thinking", False),
        reasoning_effort=record.get("reasoning_effort", DEFAULT_REASONING_EFFORT),
        status=AnalysisStatus(record["status"]),
        clarification_question=record["clarification_question"], result=record["result"],
        safety_level=record["input_safety_level"], safety_categories=record["safety_categories"],
        error_code=record["error_code"], created_at=record["created_at"], updated_at=record["updated_at"],
    )


def _result_text(decision: AgentDecision) -> str:
    if decision.action == AgentAction.ASK_CLARIFICATION:
        return decision.clarification_question or ""
    return decision.result.model_dump_json(exclude_none=True)


class GuardedTextStream:
    def __init__(self, *, guard, context: str, emit: Callable[[str], None],
                 mode: str, progress: Callable[[str], None] | None = None):
        self.guard = guard
        self.context = context
        self.emit = emit
        self.mode = mode
        self.progress = progress
        self.visible = ""
        self.error: BusinessError | None = None
        self.started = time.monotonic()
        self.first_emit_at: float | None = None
        self.guard_checks = 0
        self.guard_duration_ms = 0.0
        self.completion_logged = False
        self.threshold = 24
        self.flush_interval = 0.3
        self.queue: asyncio.Queue[tuple[str, bool] | None] = asyncio.Queue()
        self.finished = False
        self.worker = asyncio.create_task(self._consume())

    def _format(self, path: JSONPath, event: str, text: str) -> str:
        if self.mode == "summary":
            return text if path == ("summary",) and event == "delta" else ""
        if path == ("clarification_question",):
            return text if event == "delta" else ""
        if len(path) == 2 and path[0] == "result":
            labels = {
                "summary": "情境概括",
                "conflict": "核心矛盾",
                "user_needs": "你可能在意的",
                "next_step": "下一步",
                "safety_note": "安全说明",
            }
            field = path[1]
            if field in labels:
                if event == "start":
                    separator = "" if field == "summary" else "\n\n"
                    return f"{separator}{labels[field]}\n"
                return text if event == "delta" else ""
        if len(path) == 3 and path[0] == "result" and path[1] in ("emotions", "suggestions"):
            index = path[2]
            if event == "start":
                if path[1] == "emotions":
                    return ("\n\n主要情绪\n" if index == 0 else "、")
                return ("\n\n可以尝试\n1. " if index == 0 else f"\n{index + 1}. ")
            return text if event == "delta" else ""
        return ""

    async def __call__(self, path: JSONPath, event: str, text: str) -> None:
        if self.finished or self.error is not None:
            return
        formatted = self._format(path, event, text)
        if formatted or event == "end":
            await self.queue.put((formatted, event == "end"))

    async def _consume(self) -> None:
        pending = ""
        while True:
            try:
                if pending:
                    item = await asyncio.wait_for(self.queue.get(), timeout=self.flush_interval)
                else:
                    item = await self.queue.get()
            except TimeoutError:
                await self._check_and_emit(pending)
                pending = ""
                continue
            if item is None:
                await self._check_and_emit(pending)
                return
            text, force = item
            pending += text
            has_boundary = any(char in pending for char in "。！？!?;；")
            if pending and (force or len(pending) >= self.threshold or has_boundary):
                await self._check_and_emit(pending)
                pending = ""

    async def _check_and_emit(self, text: str) -> None:
        if not text or self.error is not None:
            return
        if self.progress:
            self.progress("analysis_summary_safety_check" if self.mode == "summary" else "output_safety_check")
        check_started = time.monotonic()
        try:
            result = await self.guard.check_output(self.context, self.visible + text)
        except (GuardUnavailableError, GuardProtocolError) as exc:
            logger.warning("guard_failed phase=output_stream category=%s", type(exc).__name__)
            self.error = BusinessError(503, "safety_check_unavailable")
            return
        finally:
            self.guard_checks += 1
            self.guard_duration_ms += (time.monotonic() - check_started) * 1000
        if result.safety != QwenSafetyLevel.SAFE:
            self.error = BusinessError(503, "output_rejected")
            return
        self.visible += text
        if self.first_emit_at is None:
            self.first_emit_at = time.monotonic()
        self.emit(text)

    async def finish(self) -> None:
        if not self.finished:
            self.finished = True
            await self.queue.put(None)
        await self.worker
        if not self.completion_logged:
            self.completion_logged = True
            first_emit_ms = (self.first_emit_at - self.started) * 1000 if self.first_emit_at else None
            logger.info(
                "guarded_text_stream_completed mode=%s duration_ms=%.1f first_emit_ms=%s "
                "guard_checks=%d guard_duration_ms=%.1f visible_chars=%d error=%s",
                self.mode,
                (time.monotonic() - self.started) * 1000,
                f"{first_emit_ms:.1f}" if first_emit_ms is not None else "none",
                self.guard_checks,
                self.guard_duration_ms,
                len(self.visible),
                self.error.code if self.error else "none",
            )


class AnalysisService:
    def __init__(self, *, database, provider, guard, settings, graph=None):
        self.database = database
        self.provider = provider
        self.guard = guard
        self.settings = settings
        self.graph = graph or EmoraAgentGraph(EmoraAgent(provider))
        self._session_locks = {}

    @asynccontextmanager
    async def _operation(self, session_id):
        lock, users = self._session_locks.get(session_id, (asyncio.Lock(), 0))
        self._session_locks[session_id] = (lock, users+1)
        calls, validation = [], {"schema_validation": "not_run", "domain_validation": "not_run",
                                 "summary_schema_validation": "not_run", "summary_domain_validation": "not_run"}
        session_token = session_id_var.set(session_id)
        calls_token = provider_metrics_var.set(calls)
        validation_token = validation_var.set(validation)
        start = time.monotonic()
        outcome = {"status": "failed", "error_code": None}
        try:
            async with lock:
                yield outcome
        except asyncio.CancelledError:
            outcome.update(status="cancelled", error_code="request_cancelled")
            raise
        except (SessionConflict, IntegrityError) as exc:
            outcome["error_code"] = "session_conflict"
            raise BusinessError(409, "session_conflict") from exc
        except Exception as exc:
            outcome["error_code"] = exc.code if isinstance(exc, BusinessError) else "persistence_or_internal_error"
            raise
        finally:
            logger.info("analysis_operation %s", json.dumps({
                "request_id": request_id_var.get(), "session_id": session_id,
                "duration_ms": round((time.monotonic()-start)*1000, 1),
                **outcome, **validation, "provider_calls": len(calls),
                "provider_errors": [c["error_code"] for c in calls if c.get("error_code")],
            }))
            provider_metrics_var.reset(calls_token)
            validation_var.reset(validation_token)
            session_id_var.reset(session_token)
            users = self._session_locks[session_id][1]-1
            if users:
                self._session_locks[session_id] = (lock, users)
            else:
                del self._session_locks[session_id]

    def _history(self, session_id):
        records = self.database.session_records(session_id, limit=self.settings.context_max_turns+1,
                                                completed_only=True)
        groups = []
        for record in records:
            group = [{"role": "user", "content": record["original_input"]}]
            if record["clarification_question"]:
                group.append({"role": "assistant", "content": record["clarification_question"]})
            if record["clarification_answer"]:
                group.append({"role": "user", "content": record["clarification_answer"]})
            group.append({"role": "assistant", "content": json.dumps({
                "action": "complete", "clarification_question": None, "result": record["result"]}, ensure_ascii=False)})
            groups.append(group)
        return groups

    def _bounded_history(self, groups, current):
        current_size = len(json.dumps(current, ensure_ascii=False))
        if current_size > self.settings.context_max_chars:
            raise BusinessError(422, "context_too_long")
        chosen = []
        size = current_size
        for group in reversed(groups[-self.settings.context_max_turns:]):
            cost = sum(len(message["content"]) for message in group)
            if size + cost > self.settings.context_max_chars:
                break
            chosen.insert(0, group)
            size += cost
        logger.info("context_budget selected_turns=%d dropped_loaded_turns=%d chars=%d limit=%d",
                    len(chosen), len(groups)-len(chosen), size, self.settings.context_max_chars)
        return [message for group in chosen for message in group]

    async def _input_guard(self, context: str):
        try:
            result = await self.guard.check_input(context)
        except (GuardUnavailableError, GuardProtocolError) as exc:
            logger.warning("guard_failed phase=input category=%s", type(exc).__name__)
            raise BusinessError(503, "safety_check_unavailable") from exc
        if result.safety == QwenSafetyLevel.UNSAFE:
            return result
        return result

    async def _run(self, *, original_input: str, question=None, answer=None, round_number=0,
                   history_groups=None,
                   deep_thinking: bool = False,
                   reasoning_effort: ReasoningEffort = DEFAULT_REASONING_EFFORT,
                   progress: Callable[[str], None] | None = None,
                   analysis_delta: Callable[[str], None] | None = None,
                   answer_delta: Callable[[str], None] | None = None):
        context = original_input
        if question and answer is not None:
            context = f"Original description:\n{original_input}\n\nClarification question:\n{question}\n\nUser answer:\n{answer}"
        current = {"original_input": original_input, "clarification_question": question,
                   "clarification_answer": answer, "clarification_round": round_number,
                   "analysis_summary": None}
        history = self._bounded_history(history_groups or [], current)
        if history:
            context = json.dumps({"history": history, "current": current}, ensure_ascii=False)
        if progress:
            progress("input_safety_check")
        guard = await self._input_guard(context)
        if guard.safety == QwenSafetyLevel.UNSAFE:
            return None, guard
        if progress:
            progress(f"model_reasoning_{reasoning_effort}")
        try:
            summary = None
            if deep_thinking:
                if progress:
                    progress("deep_analysis")
                summary_stream = GuardedTextStream(
                    guard=self.guard, context=context, emit=analysis_delta,
                    mode="summary", progress=progress,
                ) if analysis_delta else None
                try:
                    brief_payload = await self.provider.complete(
                        {**current, "history": history}, PublicAnalysisBrief,
                        reasoning_effort=reasoning_effort,
                        system_prompt=PUBLIC_ANALYSIS_PROMPT,
                        format_instruction=(
                            "Return exactly one JSON object matching the schema. "
                            "Do not include Markdown fences or text outside the object."
                        ),
                        on_text=summary_stream if summary_stream else None,
                    )
                finally:
                    if summary_stream:
                        await summary_stream.finish()
                if summary_stream and summary_stream.error:
                    raise summary_stream.error
                _validation("summary_schema_validation", "failed")
                summary = PublicAnalysisBrief.model_validate(brief_payload).summary.strip()
                _validation("summary_schema_validation", "passed")
                if not summary:
                    _validation("summary_domain_validation", "failed")
                    raise BusinessError(503, "domain_validation_failed")
                _validation("summary_domain_validation", "passed")
                if progress:
                    progress("analysis_summary_safety_check")
                try:
                    summary_guard = await self.guard.check_output(context, summary)
                except (GuardUnavailableError, GuardProtocolError) as exc:
                    logger.warning("guard_failed phase=summary category=%s", type(exc).__name__)
                    raise BusinessError(503, "safety_check_unavailable") from exc
                if summary_guard.safety != QwenSafetyLevel.SAFE:
                    raise BusinessError(503, "output_rejected")
                if analysis_delta and summary_stream and not summary_stream.visible:
                    analysis_delta(summary)
                history = self._bounded_history(history_groups or [], {**current,"analysis_summary":summary})
                effective = {"history": history,"current":{**current,"analysis_summary":summary}}
                context = json.dumps(effective, ensure_ascii=False)
                guard = await self._input_guard(context)
                if guard.safety == QwenSafetyLevel.UNSAFE:
                    return None, guard
            if progress:
                progress("response_generation")
            answer_stream = GuardedTextStream(
                guard=self.guard, context=context, emit=answer_delta,
                mode="decision", progress=progress,
            ) if answer_delta else None
            try:
                payload = await self.graph.ainvoke(
                    original_input=original_input,
                    clarification_question=question,
                    clarification_answer=answer,
                    clarification_round=round_number,
                    deep_thinking=deep_thinking,
                    reasoning_effort=reasoning_effort,
                    analysis_summary=summary,
                    history=history,
                    on_text=answer_stream if answer_stream else None,
                )
            finally:
                if answer_stream:
                    await answer_stream.finish()
            if answer_stream and answer_stream.error:
                raise answer_stream.error
            _validation("schema_validation", "failed")
            decision = AgentDecision.model_validate(payload)
            _validation("schema_validation", "passed")
        except BusinessError:
            raise
        except ProviderError as exc:
            raise BusinessError(503, exc.code) from exc
        except ValidationError as exc:
            logger.warning("schema_validation status=failed model_contract=AgentDecision_or_PublicAnalysisBrief")
            raise BusinessError(503, "schema_validation_failed") from exc
        except ValueError as exc:
            _validation("domain_validation", "failed")
            raise BusinessError(503, "domain_validation_failed") from exc
        except Exception as exc:
            logger.warning("analysis_internal_failure category=%s", type(exc).__name__)
            raise BusinessError(503, "analysis_unavailable") from exc

        if round_number == 1 and decision.action == AgentAction.ASK_CLARIFICATION:
            _validation("domain_validation", "failed")
            raise BusinessError(500, "clarification_limit_exceeded")
        if decision.action == AgentAction.COMPLETE:
            result = decision.result
            if not all([
                result.summary.strip(), result.conflict.strip(), result.user_needs.strip(),
                result.next_step.strip(), *[value.strip() for value in result.emotions],
                *[value.strip() for value in result.suggestions],
            ]):
                _validation("domain_validation", "failed")
                raise BusinessError(500, "invalid_analysis_result")
        _validation("domain_validation", "passed")
        try:
            if progress:
                progress("output_safety_check")
            output = await self.guard.check_output(context, _result_text(decision))
        except (GuardUnavailableError, GuardProtocolError) as exc:
            logger.warning("guard_failed phase=output category=%s", type(exc).__name__)
            raise BusinessError(503, "safety_check_unavailable") from exc
        if output.safety != QwenSafetyLevel.SAFE:
            raise BusinessError(503, "output_rejected")
        return decision, guard

    async def create(self, text: str, *, deep_thinking: bool = False,
                     session_id: str | None = None,
                     reasoning_effort: ReasoningEffort = DEFAULT_REASONING_EFFORT,
                     progress=None, analysis_delta=None, answer_delta=None):
        new_session = session_id is None
        session_id = session_id or uuid4().hex
        async with self._operation(session_id) as outcome:
            previous = self.database.session_records(session_id, limit=1)
            if not new_session and not previous:
                raise BusinessError(404, "session_not_found")
            if previous and previous[-1]["status"] == "waiting_clarification":
                raise BusinessError(409, "session_waiting_clarification")
            response = await self._create(text, deep_thinking=deep_thinking, session_id=session_id,
                expected_turn=previous[-1]["turn_index"]+1 if previous else 0,
                reasoning_effort=reasoning_effort, progress=progress, analysis_delta=analysis_delta,
                answer_delta=answer_delta)
            outcome.update(status=response.status.value,error_code=response.error_code,analysis_id=response.id)
            return response

    async def _create(self, text: str, *, deep_thinking: bool = False,
                     session_id: str, expected_turn: int,
                     reasoning_effort: ReasoningEffort = DEFAULT_REASONING_EFFORT,
                     progress: Callable[[str], None] | None = None,
                     analysis_delta: Callable[[str], None] | None = None,
                     answer_delta: Callable[[str], None] | None = None) -> AnalysisResponse:
        validate_input_length(text, self.settings.max_input_length)
        try:
            decision, guard = await self._run(original_input=text, deep_thinking=deep_thinking,
                                              history_groups=self._history(session_id),
                                              reasoning_effort=reasoning_effort,
                                              progress=progress, analysis_delta=analysis_delta,
                                              answer_delta=answer_delta)
        except BusinessError as exc:
            logger.warning("analysis_failed code=%s", exc.code)
            if progress:
                progress("result_persistence")
            record = self.database.create(text, "failed", error_code=exc.code,
                                          session_id=session_id, expected_turn=expected_turn,
                                          deep_thinking=deep_thinking, reasoning_effort=reasoning_effort)
            return _response(record)
        if progress:
            progress("result_persistence")
        if decision is None:
            urgent = any(category in guard.categories for category in (
                QwenSafetyCategory.SUICIDE_SELF_HARM, QwenSafetyCategory.VIOLENT,
            ))
            record = self.database.create(text, "blocked", guard=guard,
                                          session_id=session_id, expected_turn=expected_turn,
                                          error_code="unsafe_input_seek_support" if urgent else "unsafe_input",
                                          deep_thinking=deep_thinking, reasoning_effort=reasoning_effort)
            return _response(record)
        if decision.action == AgentAction.ASK_CLARIFICATION:
            record = self.database.create(
                text, "waiting_clarification", guard=guard,
                session_id=session_id, expected_turn=expected_turn,
                clarification_question=decision.clarification_question,
                deep_thinking=deep_thinking,
                reasoning_effort=reasoning_effort,
            )
        else:
            record = self.database.create(text, "completed", guard=guard,
                                          session_id=session_id, expected_turn=expected_turn,
                                          result=decision.result.model_dump(mode="json"),
                                          deep_thinking=deep_thinking,
                                          reasoning_effort=reasoning_effort)
        return _response(record)

    async def continue_with_answer(self, analysis_id: str, answer: str, *,
                                   deep_thinking: bool | None = None,
                                   reasoning_effort: ReasoningEffort | None = None,
                                   progress=None, analysis_delta=None, answer_delta=None):
        previous = self.database.get(analysis_id)
        if previous is None:
            raise BusinessError(404, "analysis_not_found")
        async with self._operation(previous["session_id"]) as outcome:
            response = await self._continue_with_answer(analysis_id,answer,deep_thinking=deep_thinking,
                reasoning_effort=reasoning_effort,progress=progress,analysis_delta=analysis_delta,answer_delta=answer_delta)
            outcome.update(status=response.status.value,error_code=response.error_code,analysis_id=response.id)
            return response

    async def _continue_with_answer(self, analysis_id: str, answer: str, *,
                                   deep_thinking: bool | None = None,
                                   reasoning_effort: ReasoningEffort | None = None,
                                   progress: Callable[[str], None] | None = None,
                                   analysis_delta: Callable[[str], None] | None = None,
                                   answer_delta: Callable[[str], None] | None = None) -> AnalysisResponse:
        validate_input_length(answer, self.settings.max_input_length)
        previous = self.database.get(analysis_id)
        if previous is None:
            raise BusinessError(404, "analysis_not_found")
        if previous["status"] != AnalysisStatus.WAITING_CLARIFICATION.value:
            raise BusinessError(422, "analysis_not_waiting_clarification")
        deep_thinking = previous["deep_thinking"] if deep_thinking is None else deep_thinking
        reasoning_effort = previous.get("reasoning_effort", DEFAULT_REASONING_EFFORT) \
            if reasoning_effort is None else reasoning_effort
        try:
            decision, guard = await self._run(
                original_input=previous["original_input"],
                history_groups=self._history(previous["session_id"]),
                question=previous["clarification_question"], answer=answer, round_number=1,
                deep_thinking=deep_thinking, progress=progress, analysis_delta=analysis_delta,
                answer_delta=answer_delta,
                reasoning_effort=reasoning_effort,
            )
        except BusinessError as exc:
            logger.warning("analysis_failed code=%s", exc.code)
            if exc.code != "analysis_not_found" and exc.code != "analysis_not_waiting_clarification":
                if progress:
                    progress("result_persistence")
                record = self.database.update(analysis_id, status="failed", clarification_answer=answer,
                                              expected_updated_at=previous["updated_at"],
                                              error_code=exc.code, deep_thinking=deep_thinking,
                                              reasoning_effort=reasoning_effort)
                return _response(record)
            raise
        if progress:
            progress("result_persistence")
        if decision is None:
            urgent = any(category in guard.categories for category in (
                QwenSafetyCategory.SUICIDE_SELF_HARM, QwenSafetyCategory.VIOLENT,
            ))
            record = self.database.update(analysis_id, status="blocked", guard=guard,
                                          expected_updated_at=previous["updated_at"],
                                          clarification_answer=answer,
                                          error_code="unsafe_input_seek_support" if urgent else "unsafe_input",
                                          deep_thinking=deep_thinking, reasoning_effort=reasoning_effort)
        else:
            record = self.database.update(analysis_id, status="completed", guard=guard,
                                          expected_updated_at=previous["updated_at"],
                                          clarification_answer=answer,
                                          result=decision.result.model_dump(mode="json"),
                                          deep_thinking=deep_thinking,
                                          reasoning_effort=reasoning_effort)
        return _response(record)

    def get(self, analysis_id: str) -> AnalysisResponse:
        record = self.database.get(analysis_id)
        if record is None:
            raise BusinessError(404, "analysis_not_found")
        return _response(record)

    def list(self) -> list[AnalysisResponse]:
        return [_response(record) for record in self.database.list()]

    def session_history(self, session_id, *, before=None):
        records, next_before = self.database.session_page(session_id, before=before)
        if not records and not self.database.session_records(session_id, limit=1):
            raise BusinessError(404, "session_not_found")
        return {"session_id":session_id,"items":[_response(record) for record in records],"next_before":next_before}

    async def close(self):
        return None
