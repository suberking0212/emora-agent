from pathlib import Path
from collections.abc import Awaitable, Callable
import logging
import json
import time

from openai import AsyncOpenAI
from pydantic import BaseModel

logger = logging.getLogger(__name__)
DEEP_THINKING_MAX_COMPLETION_TOKENS = 4096
JSONPath = tuple[str | int, ...]
TextStreamHandler = Callable[[JSONPath, str, str], Awaitable[None]]


class IncrementalJSONText:
    """Extract string-value deltas from a JSON document as it arrives."""

    def __init__(self):
        self.stack: list[dict] = []
        self.root_state = "value"
        self.mode = "normal"
        self.string_role = ""
        self.string_path: JSONPath = ()
        self.string_key: list[str] = []
        self.escape = False
        self.unicode_digits: list[str] | None = None
        self.high_surrogate: int | None = None

    def _consume_value(self) -> JSONPath | None:
        if not self.stack:
            if self.root_state == "value":
                self.root_state = "done"
                return ()
            return None
        frame = self.stack[-1]
        if frame["kind"] == "object" and frame["state"] == "value":
            path = (*frame["path"], frame["key"])
            frame["key"] = None
            frame["state"] = "comma_or_end"
            return path
        if frame["kind"] == "array" and frame["state"] == "value_or_end":
            path = (*frame["path"], frame["index"])
            frame["index"] += 1
            frame["state"] = "comma_or_end"
            return path
        return None

    def _start_string(self, role: str, path: JSONPath) -> None:
        self.mode = "string"
        self.string_role = role
        self.string_path = path
        self.string_key = []
        self.escape = False
        self.unicode_digits = None
        self.high_surrogate = None

    @staticmethod
    def _flush_delta(events: list, decoded: list[str], path: JSONPath) -> None:
        if decoded:
            events.append(("delta", path, "".join(decoded)))
            decoded.clear()

    def _append_decoded(self, char: str, decoded: list[str]) -> None:
        if self.string_role == "key":
            self.string_key.append(char)
        else:
            decoded.append(char)

    def _append_code_unit(self, code: int, decoded: list[str]) -> None:
        if self.high_surrogate is not None:
            if 0xDC00 <= code <= 0xDFFF:
                scalar = 0x10000 + ((self.high_surrogate - 0xD800) << 10) + (code - 0xDC00)
                self._append_decoded(chr(scalar), decoded)
                self.high_surrogate = None
                return
            self._append_decoded("\ufffd", decoded)
            self.high_surrogate = None
        if 0xD800 <= code <= 0xDBFF:
            self.high_surrogate = code
        elif 0xDC00 <= code <= 0xDFFF:
            self._append_decoded("\ufffd", decoded)
        else:
            self._append_decoded(chr(code), decoded)

    def _normal(self, char: str) -> None:
        if char in " \t\r\n":
            return
        if char == "{":
            path = self._consume_value()
            self.stack.append({"kind": "object", "path": path or (), "state": "key_or_end", "key": None})
        elif char == "[":
            path = self._consume_value()
            self.stack.append({"kind": "array", "path": path or (), "state": "value_or_end", "index": 0})
        elif char == '"' and self.stack and self.stack[-1]["kind"] == "object" \
                and self.stack[-1]["state"] == "key_or_end":
            self._start_string("key", self.stack[-1]["path"])
        elif char == '"':
            path = self._consume_value()
            if path is not None:
                self._start_string("value", path)
        elif char == ":" and self.stack and self.stack[-1]["kind"] == "object":
            if self.stack[-1]["state"] == "colon":
                self.stack[-1]["state"] = "value"
        elif char == "," and self.stack:
            frame = self.stack[-1]
            if frame["state"] == "comma_or_end":
                frame["state"] = "key_or_end" if frame["kind"] == "object" else "value_or_end"
        elif char == "}" and self.stack and self.stack[-1]["kind"] == "object":
            self.stack.pop()
        elif char == "]" and self.stack and self.stack[-1]["kind"] == "array":
            self.stack.pop()
        else:
            path = self._consume_value()
            if path is not None:
                self.mode = "primitive"

    def feed(self, fragment: str) -> list[tuple[str, JSONPath, str]]:
        events: list[tuple[str, JSONPath, str]] = []
        decoded: list[str] = []
        for char in fragment:
            if self.mode == "primitive":
                if char in ",]} \t\r\n":
                    self.mode = "normal"
                    self._normal(char)
                continue
            if self.mode == "normal":
                prior_mode = self.mode
                self._normal(char)
                if prior_mode == "normal" and self.mode == "string" and self.string_role == "value":
                    events.append(("start", self.string_path, ""))
                continue

            if self.unicode_digits is not None:
                self.unicode_digits.append(char)
                if len(self.unicode_digits) == 4:
                    try:
                        self._append_code_unit(int("".join(self.unicode_digits), 16), decoded)
                    except ValueError:
                        decoded.append("\ufffd")
                    self.unicode_digits = None
                continue
            if self.escape:
                self.escape = False
                if char == "u":
                    self.unicode_digits = []
                else:
                    self._append_decoded({
                        '"': '"', "\\": "\\", "/": "/", "b": "\b",
                        "f": "\f", "n": "\n", "r": "\r", "t": "\t",
                    }.get(char, "\ufffd"), decoded)
                continue
            if char == "\\":
                self.escape = True
            elif char == '"':
                if self.high_surrogate is not None:
                    self._append_decoded("\ufffd", decoded)
                    self.high_surrogate = None
                if self.string_role == "value":
                    self._flush_delta(events, decoded, self.string_path)
                    events.append(("end", self.string_path, ""))
                else:
                    frame = self.stack[-1]
                    frame["key"] = "".join(self.string_key)
                    frame["state"] = "colon"
                self.mode = "normal"
                self.string_role = ""
            else:
                if self.string_role == "key":
                    self.string_key.append(char)
                else:
                    decoded.append(char)

        if self.mode == "string" and self.string_role == "value":
            self._flush_delta(events, decoded, self.string_path)
        return events


class PublicAnalysisBrief(BaseModel):
    summary: str


PUBLIC_ANALYSIS_PROMPT = (
    "为情绪支持对话生成面向用户的分析提要。用两三句中文回应用户明确表达的感受，概括已知事实与尚不确定之处，并说明正式回复会如何提供帮助。语气温和具体，不把假设说成事实，不诊断，不编造个人背景，也不输出私有推理过程或隐藏思维链。只返回符合给定 JSON Schema 的对象。"
)


class ProviderError(RuntimeError):
    pass


class ProviderAdapter:
    def __init__(self, *, model: str, api_key: str, api_base: str | None, timeout_seconds: float):
        self.model = model
        self.client = AsyncOpenAI(
            api_key=api_key,
            base_url=api_base,
            timeout=timeout_seconds,
            max_retries=0,
        )
        self.system_prompt = Path(__file__).parent.joinpath("prompts/system.md").read_text()

    async def complete(self, context: dict, response_model: type[BaseModel], *,
                       deep_thinking: bool = False,
                       reasoning_effort: str = "medium",
                       system_prompt: str | None = None,
                       format_instruction: str | None = None,
                       on_text: TextStreamHandler | None = None) -> dict:
        started = time.monotonic()
        try:
            # This gateway documents ordinary chat completions, not native
            # json_schema response_format. Keep the wire request within that
            # contract and describe the required object in the trusted prompt.
            schema = json.dumps(response_model.model_json_schema(), ensure_ascii=False)
            format_instruction = format_instruction or (
                "Return exactly one JSON object matching the following JSON Schema. "
                "Do not include Markdown fences, reasoning, or text outside the object. "
                "For ask_clarification, set result to null and provide one clarification_question. "
                "For complete, set clarification_question to null and provide the complete result. "
            )
            deep_thinking_prompt = ""
            if deep_thinking:
                deep_thinking_prompt = (
                    "\n\nDeep-thinking mode is enabled. Carefully examine the stated facts, "
                    "plausible interpretations, missing context, emotional needs, and practical "
                    "low-risk options. Use only personal details present in the supplied context; "
                    "separate facts from hypotheses and explain how relevant factors may interact. "
                    "Make the existing result fields more specific and useful: prioritize a small "
                    "set of concrete suggestions, give brief reasons where helpful, and make the "
                    "next step easy to act on. Keep uncertainty explicit; do not diagnose, assert "
                    "unsupported causes, or amplify concern beyond the evidence. If essential "
                    "information is missing, ask exactly one focused clarification question as "
                    "allowed by the current round. Do not add schema fields or reveal chain-of-thought, "
                    "scratch work, or private deliberation; return only the requested final JSON."
                )
            request = {
                "model": self.model,
                "messages": [
                    {"role": "system", "content": (system_prompt or self.system_prompt) + deep_thinking_prompt +
                     "\n\n" + format_instruction + "\nSchema:\n" + schema},
                    {"role": "user", "content": json.dumps(context, ensure_ascii=False)},
                ],
                "stream": True,
            }
            request["reasoning_effort"] = reasoning_effort
            if deep_thinking:
                request["max_completion_tokens"] = DEEP_THINKING_MAX_COMPLETION_TOKENS
            stream = await self.client.chat.completions.create(**request)
            content_parts = []
            text_parser = IncrementalJSONText() if on_text else None
            finish_reason = None
            first_content_at = None
            content_events = 0
            content_chars = 0
            try:
                async for chunk in stream:
                    if not chunk.choices:
                        continue
                    choice = chunk.choices[0]
                    if choice.delta.content:
                        fragment = choice.delta.content
                        if first_content_at is None:
                            first_content_at = time.monotonic()
                        content_events += 1
                        content_chars += len(fragment)
                        content_parts.append(fragment)
                        if text_parser and on_text:
                            for event, path, text in text_parser.feed(fragment):
                                await on_text(path, event, text)
                    if choice.finish_reason is not None:
                        finish_reason = choice.finish_reason
            finally:
                await stream.close()
            if finish_reason != "stop":
                raise ProviderError("provider_incomplete_response")
            content = "".join(content_parts)
            if not content.strip():
                raise ProviderError("provider_empty_response")
            payload = json.loads(content)
            if not isinstance(payload, dict):
                raise ProviderError("provider_invalid_response_shape")
            first_content_ms = (first_content_at - started) * 1000 if first_content_at else None
            logger.info(
                "provider_stream_completed duration_ms=%.1f first_content_ms=%s "
                "content_events=%d content_chars=%d",
                (time.monotonic() - started) * 1000,
                f"{first_content_ms:.1f}" if first_content_ms is not None else "none",
                content_events,
                content_chars,
            )
            # Schema/domain validation is performed once by AnalysisService.
            return payload
        except ProviderError:
            raise
        except Exception as exc:
            logger.warning(
                "provider_request_failed error_type=%s cause_type=%s status=%s duration_ms=%.1f",
                type(exc).__name__, type(exc.__cause__).__name__ if exc.__cause__ else "none",
                getattr(exc, "status_code", None),
                (time.monotonic() - started) * 1000,
            )
            raise ProviderError("provider_request_failed") from exc

    async def close(self) -> None:
        await self.client.close()
