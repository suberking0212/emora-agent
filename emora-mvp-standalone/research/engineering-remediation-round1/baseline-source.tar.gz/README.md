# Emora MVP Standalone

## Requirements

- Python 3.11+
- An OpenAI-compatible analysis model endpoint
- A local Qwen3Guard-Gen endpoint (bundled Transformers launcher for Mac, or external vLLM)

Install and configure:

```bash
cd emora-mvp-standalone
uv sync
cp .env.example .env
```

Set `EMORA_MODEL`, `EMORA_API_KEY`, and `EMORA_API_BASE` in `.env`. On Apple Silicon, install the official 0.6B weights once:

```bash
./install-guard.sh
```

Start or restart the app from this directory (the FastAPI backend also serves the separated frontend files):

```bash
./start.sh
```

The script stops the previous project stack, starts local Guard and waits for model readiness, then starts Web and its same-origin frontend. Both services print logs to the current terminal; log files are `backend/data/guard.log` and `backend/data/server.log`. It verifies the real server PIDs own their fixed ports and pass health checks, without automatically switching ports or killing unrelated applications. Press `Ctrl+C` to stop both, or use `./start.sh --stop` from another terminal. Set `EMORA_HOST` or `EMORA_PORT` to override Web defaults. An external Guard URL is not launched or stopped locally. `./start-guard.sh` remains available for independent Guard troubleshooting.

The SQLite database defaults to `backend/data/emora.db`. Run infrastructure checks with `uv run pytest`. Tests only check startup and connectivity; they do not establish product quality or safety coverage. Select a Qwen3Guard checkpoint that fits the deployment machine.

The analysis provider uses native `stream=true` Chat Completions. The server incrementally extracts user-facing text from streamed JSON fields. A separate ordered worker checks the accumulated prefix and releases a fragment after about 24 characters, a sentence boundary, or 300 ms, without pausing reads from the model stream. The complete response still must pass JSON/domain validation, a full output safety check, and persistence before it is confirmed. In deep-thinking mode, the public analysis summary streams while it is generated and then becomes context for the final answer. It is not private chain-of-thought. Provider and Guard logs record first-content/first-visible latency, chunk counts, and check duration without logging generated text, which helps distinguish upstream buffering from application-side delays. This app currently invokes no agent skills or tools, and the existing JSON endpoints remain available for scripts.

The composer includes a default-off deep-thinking option and a native reasoning-effort selector. The runtime endpoint reads the current model name from the provider and advertises all supported effort values (`none`, `low`, `medium`, `high`, `xhigh`, `max`). The selected value is sent on both analysis and clarification requests, passed to every provider completion, and persisted with the analysis record; older SQLite rows default to `medium`. Deep mode adds a separate analysis-summary generation pass and a more careful final-answer instruction with the documented `max_completion_tokens` budget. The app never returns private chain-of-thought.

See [`doc/OPERATIONS.md`](doc/OPERATIONS.md) for the Chinese startup/configuration guide and troubleshooting table.
