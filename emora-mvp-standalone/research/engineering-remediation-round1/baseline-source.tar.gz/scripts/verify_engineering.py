"""Repeatable, opt-in engineering verification; never uses the application database."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "research/engineering-remediation-round1"


def write_json(name, value):
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    (EVIDENCE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def source_files():
    roots = [ROOT / name for name in ("backend", "frontend", "scripts", "doc")]
    files = [p for base in roots for p in base.rglob("*") if p.is_file()
             and "__pycache__" not in p.parts and "data" not in p.relative_to(ROOT).parts
             and p.suffix in {".py", ".js", ".css", ".html", ".md", ".sh"}]
    files.extend(p for p in ROOT.iterdir() if p.is_file() and
                 (p.name in {".env.example", ".gitignore", "pyproject.toml", "uv.lock"}
                  or p.suffix in {".md", ".sh"}))
    return sorted(set(files))


def baseline():
    if (EVIDENCE / "baseline.json").exists():
        raise SystemExit("Baseline already exists; refusing to replace it")
    files = source_files()
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    with tarfile.open(EVIDENCE / "baseline-source.tar.gz", "w:gz") as archive:
        for path in files:
            archive.add(path, arcname=str(path.relative_to(ROOT)))
    status = subprocess.check_output(["git", "status", "--short", "--branch"], cwd=ROOT, text=True)
    write_json("baseline.json", {
        "captured_at": datetime.now(timezone.utc).isoformat(), "git_status": status,
        "files": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
        "excluded": ["secrets", "databases", "logs", "virtualenvs", "research artifacts"],
    })
    print(f"Baseline: {len(files)} source/document files; no credentials or user data")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["baseline"])
    args = parser.parse_args()
    if args.command == "baseline":
        baseline()


if __name__ == "__main__":
    main()
